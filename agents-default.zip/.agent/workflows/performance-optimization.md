# Workflow: performance-optimization

Purpose: Systematically identify and fix performance bottlenecks using measurable, repeatable, and data-driven steps.

Total estimate: ~250 minutes plus iterative optimization cycles.

## 1. Baseline Measurement (10 minutes)

Actions:
- Run Lighthouse in Antigravity browser.
- Measure Core Web Vitals (LCP, FID, CLS).
- Check bundle size with `webpack-bundle-analyzer`.
- Profile initial page load waterfall and long tasks.
- Measure API response times (p50/p95).
- Test baseline on mobile devices/network profiles.

Output:
- `baseline-metrics.md`

## 2. Frontend Profiling (20 minutes)

Actions:
- Use React Profiler to identify slow components.
- Detect unnecessary re-renders.
- Analyze bundle composition and chunk sizes.
- Identify large dependencies and dead-weight imports.
- Check image sizes, formats, and delivery strategy.
- Measure JavaScript execution and hydration costs.
- Profile CSS cost (unused rules, style recalculation hot spots).

Output:
- `frontend-profile-report.md`

## 3. Backend Profiling (20 minutes)

Actions:
- Profile critical API endpoints.
- Analyze database query performance.
- Detect N+1 query patterns.
- Review slow query logs.
- Profile third-party/external API latency.
- Check service memory and CPU usage patterns.

Output:
- `backend-profile-report.md`

## 4. Opportunity Identification (15 minutes)

Actions:
- List all optimization opportunities.
- Prioritize by impact vs effort.
- Categorize opportunities: frontend/backend/infrastructure.
- Set specific performance goals for each target area.
- Build an optimization sequence plan.

Output:
- `optimization-opportunities.md`

## 5. Frontend Optimizations (45 minutes)

Actions:
- Optimize images (WebP/AVIF, responsive sizing).
- Implement code splitting.
- Add lazy loading for below-fold assets/components.
- Memoize expensive components when profiling justifies.
- Remove unused dependencies/modules.
- Optimize CSS (remove unused rules, minify).
- Add service worker caching strategy where appropriate.
- Implement resource prefetching/preloading.

Output:
- Frontend optimizations

## 6. Backend Optimizations (45 minutes)

Actions:
- Add database indexes.
- Optimize query shapes and query plans.
- Implement Redis caching.
- Configure connection pooling.
- Reduce API payload sizes.
- Add response compression.
- Cache query results for expensive reads.
- Batch database operations where safe.

Output:
- Backend optimizations

## 7. Asset Optimizations (20 minutes)

Actions:
- Compress image assets.
- Minify JavaScript and CSS.
- Configure CDN for static assets.
- Add/verify cache headers.
- Optimize font loading strategy.
- Add resource hints (`preload`, `preconnect`, `prefetch`).

Output:
- Asset optimizations

## 8. React-Specific Optimizations (30 minutes)

Actions:
- Add `React.memo` where beneficial.
- Optimize `useCallback` and `useMemo` usage.
- Implement virtualization for long lists.
- Split oversized components.
- Use React Server Components where applicable.
- Add Suspense boundaries for async segments.
- Optimize context providers/consumers to reduce rerenders.

Output:
- React optimizations

## 9. Infrastructure Optimizations (30 minutes)

Actions:
- Optimize Docker images (multi-stage, minimal runtime footprint).
- Implement/validate horizontal scaling strategy.
- Add or tune load balancing.
- Verify CDN configuration and cache behavior.
- Optimize database runtime configuration.
- Add/adjust caching layers.

Output:
- Infrastructure optimizations

## 10. Testing and Verification (30 minutes)

Actions:
- Re-run Lighthouse and profiling tests.
- Measure updated Core Web Vitals.
- Compare before/after metrics.
- Test across device classes and network conditions.
- Verify functionality and UX integrity.
- Check for regressions.

Output:
- `performance-improvement-report.md`

## 11. Performance Budget Setup (10 minutes)

Actions:
- Set bundle size budget.
- Set Core Web Vitals targets.
- Configure CI checks for performance budgets.
- Add continuous performance monitoring.

Output:
- `performance-budget.json`

## Performance Goals

- Lighthouse score: `90+` across all categories.
- LCP: `< 2.5s`
- FID: `< 100ms`
- CLS: `< 0.1`
- TTI: `< 3.5s`
- FCP: `< 1.8s`
- Bundle size: `< 200KB` initial load (compressed target).

## Quick Wins to Prioritize

1. Image optimization
2. Code splitting
3. Database indexes
4. Response caching
5. CDN implementation

## Parallel Execution Plan

Use Agent Manager to parallelize:
- Steps 2 and 3 can run in parallel.
- Steps 5 and 6 can run in parallel after opportunity prioritization.
- Merge results before step 10 verification.

## Measurement Strategy

Rules:
- Measure before each major change.
- Measure after each major change.
- Track cumulative improvement over baseline.
- Use realistic, real-world user scenarios (mobile, slower networks, typical data volumes).

Required comparison format:
1. Baseline value
2. Post-change value
3. Delta (absolute and percentage)
4. User-facing impact summary
