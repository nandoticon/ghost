# Workflow: security-audit

Purpose: Proactively identify and fix security vulnerabilities across application code, APIs, browser flows, and infrastructure.

Total estimate: ~200 minutes plus variable remediation time.

## 1. Scope Definition (5 minutes)

Actions:
- Identify audit scope (entire app or specific feature).
- List all entry points (API endpoints, forms, file uploads, webhooks).
- Document authentication and authorization flows.
- Identify sensitive data handling paths.

Output:
- `audit-scope.md`

## 2. Dependency Audit (10 minutes)

Actions:
- Run `npm audit` or `yarn audit`.
- Check for outdated packages.
- Review package licenses.
- Identify unused dependencies.
- Generate dependency risk summary.

Output:
- `dependency-audit-report.md`

## 3. Code Analysis (30 minutes)

Actions:
- Scan for hardcoded secrets.
- Check SQL injection risks.
- Review XSS exposure points.
- Verify CSRF protection.
- Audit authentication implementation.
- Audit authorization logic for privilege/ownership checks.
- Verify input validation coverage.
- Check for insecure deserialization patterns.

Output:
- `code-security-findings.md`

## 4. Configuration Review (15 minutes)

Actions:
- Verify security headers are set correctly.
- Review CORS policy.
- Review TLS/SSL configuration.
- Verify environment variable setup.
- Check cookie security flags.
- Review rate limiting configuration.

Output:
- `configuration-review.md`

## 5. Authentication and Authorization Audit (20 minutes)

Actions:
- Test authentication flows.
- Verify password policies.
- Review session management.
- Test authorization on all relevant endpoints.
- Verify logout invalidates sessions/tokens.
- Test privilege escalation scenarios.
- Test account lockout/throttling mechanism.

Output:
- `auth-audit-report.md`

## 6. Data Protection Review (15 minutes)

Actions:
- Verify encryption at rest.
- Verify TLS for data in transit.
- Review password hashing implementation.
- Check sensitive data leakage in logs.
- Verify data sanitization and redaction.
- Review backup security controls.

Output:
- `data-protection-report.md`

## 7. API Security Testing (20 minutes)

Actions:
- Test rate limiting behavior.
- Verify API authentication and authorization.
- Test input validation boundaries.
- Check error messages for information leakage.
- Test file upload restrictions.
- Verify API versioning conventions.
- Test CORS behavior under varied origins/headers.

Output:
- `api-security-report.md`

## 8. Browser Security Testing (25 minutes)

Actions:
- Use Antigravity browser for runtime security checks.
- Test forms for XSS vectors.
- Verify CSRF protection in browser flows.
- Test clickjacking defenses.
- Check sensitive data in `localStorage`/`sessionStorage`.
- Verify session/cookie security behavior.
- Confirm secure contexts (HTTPS-only behavior).

Output:
- `browser-security-report.md`

## 9. Infrastructure Review (15 minutes)

Actions:
- Review Docker/container security configuration.
- Check exposed ports and network boundaries.
- Verify least-privilege access controls.
- Review logging and audit-log configuration.
- Check monitoring and alerting setup.
- Verify backup procedures and restore readiness.

Output:
- `infrastructure-report.md`

## 10. Remediation Plan (15 minutes)

Actions:
- Prioritize findings by severity.
- Create fix plan per finding.
- Estimate fix effort and sequencing.
- Identify quick wins.
- Flag findings requiring human/security review.

Output:
- `remediation-plan.md`

## 11. Fix Implementation (Variable time)

Actions:
- Implement fixes systematically, starting with critical issues.
- Test each fix during implementation.
- Document security changes.
- Update security documentation and controls.

Output:
- Security fixes

## 12. Verification (20 minutes)

Actions:
- Re-test all identified vulnerabilities.
- Verify fixes behave as expected.
- Re-run automated security scans.
- Test for regressions in related areas.

Output:
- `verification-report.md`

## Security Severity Levels

- Critical: immediate data breach risk (example: SQL injection, auth bypass).
- High: significant security risk (example: XSS, CSRF, exposed secrets).
- Medium: potential security issue (example: weak validation, missing headers).
- Low: security improvement (example: outdated dependencies, hardening gaps).

## Automated Tools to Use

- `npm audit` / `yarn audit` for dependency vulnerabilities.
- ESLint security plugins for static analysis.
- Trufflehog for secret scanning.
- OWASP ZAP for dynamic testing when available.

## Parallel Execution Plan

Use Agent Manager to parallelize:
- Steps 2, 3, and 4 can run in parallel.
- Steps 5, 6, 7, and 8 can run in parallel after scope and baseline findings are ready.
- Consolidate findings before starting remediation planning (step 10).

## Human Review Required

Mandatory human review for:
- Critical and High severity findings.
- Changes to authentication logic.
- Infrastructure changes.

## Exit Criteria

Audit is complete only when:
1. All Critical issues are fixed or explicitly risk-accepted by authorized human reviewer.
2. High issues have fix plans with owners and deadlines.
3. Verification report confirms no regression for fixed vulnerabilities.
4. Security documentation is updated with decisions and residual risks.
