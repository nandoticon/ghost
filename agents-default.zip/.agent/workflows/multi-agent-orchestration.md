# Workflow: multi-agent-orchestration

Purpose: Define how multiple specialized agents coordinate effectively on complex features.

## 1. Orchestration Patterns

### Pattern A: Parallel Development

```text
Feature Request -> Task Decomposition
├─ Agent 1: Backend API (senior-fullstack-engineer)
├─ Agent 2: Frontend UI (senior-fullstack-engineer)
├─ Agent 3: Tests (qa-engineer)
└─ Agent 4: Documentation (technical-writer)

-> Integration -> Review -> Deploy
```

Usage:
- Best for full-stack features with clear contracts.
- Requires upfront API/schema definition and file ownership boundaries.

### Pattern B: Sequential Pipeline

```text
Feature Request
-> Design Agent (architect)
-> Implementation Agent (senior-fullstack-engineer)
-> Security Review Agent (security-specialist)
-> Performance Optimization Agent (performance-engineer)
-> QA Agent (qa-engineer)
-> DevOps Agent (devops-engineer)
-> Deploy
```

Usage:
- Best for high-risk changes requiring strict stage gates.

### Pattern C: Review-Based Workflow

```text
Code Implementation (developer-agent)
├─ Security Review (security-specialist) -> Pass/Fail
├─ Performance Review (performance-engineer) -> Pass/Fail
└─ Code Quality Review (senior-engineer) -> Pass/Fail

All Pass -> Deploy
Any Fail -> Fix -> Re-review
```

Usage:
- Best for release-critical or compliance-sensitive changes.

## 2. Agent Coordination Rules

### File Ownership
- One agent owns one file at a time.
- Use dedicated branches for parallel work.
- Integration ownership stays with the orchestrator agent.

### Communication
- Agents communicate through shared artifacts.
- Main orchestrator tracks dependencies and blockers.
- Each handoff must include status: `Ready for Review` or `Blocking on <reason>`.

### Conflict Resolution
- Non-critical files: last-write wins with reviewer confirmation.
- Critical conflicts (auth, schema, security, infra): mandatory human review.
- After conflict resolution: run integration tests and smoke checks.

## 3. Use Cases

### Use Case 1: Full-Stack Feature Development

```text
User Story: Add user profile editing

Orchestration:
1. Architect designs feature (15 min)
2. Parallel:
   - Backend agent builds API (30 min)
   - Frontend agent builds UI (30 min)
   - DevOps agent prepares deployment (20 min)
3. Main agent integrates (15 min)
4. Parallel review:
   - Security review (15 min)
   - Performance review (15 min)
5. QA tests (20 min)
6. Deploy (10 min)

Total: ~2 hours (parallelized)
```

### Use Case 2: Bug Fix Sprint

```text
Multiple bugs reported

Orchestration:
1. Spawn one debug agent per bug
2. Each follows debug-issue workflow
3. Coordinate shared-file changes
4. Merge fixes sequentially for stability
5. Single QA pass validates all fixes
6. Deploy
```

### Use Case 3: Security Audit and Fix

```text
Security audit requested

Orchestration:
1. Security agent runs complete audit
2. Creates prioritized remediation list
3. Spawn multiple implementation agents for parallel fixes
4. Security agent re-reviews each fix
5. Integrate and test
6. Deploy
```

## 4. Agent Selection Matrix

| Task Type | Primary Agent | Support Agents |
| :--- | :--- | :--- |
| New Feature | senior-fullstack-engineer | security-specialist, performance-engineer |
| Bug Fix | senior-fullstack-engineer | debug-specialist |
| Security Audit | security-specialist | devops-engineer |
| Performance Issue | performance-engineer | devops-engineer |
| Infrastructure | devops-engineer | security-specialist |
| Refactoring | senior-fullstack-engineer | all reviewers as needed |

## 5. Coordination Artifacts

- `task-decomposition.md` (work split and ownership)
- `integration-plan.md` (merge/integration sequence)
- `progress-tracker.md` (live status by agent)
- `merge-strategy.md` (conflict and merge handling)

## 6. Best Practices

1. Start with clear decomposition and interfaces.
2. Define ownership before parallel coding begins.
3. Keep branches focused and short-lived.
4. Integrate frequently to reduce drift.
5. Use one orchestrator agent to coordinate dependencies.
6. Document key decisions in shared artifacts.

## 7. When to Use Multi-Agent

- Feature spans frontend + backend + infrastructure
- Multiple urgent bugs need parallel handling
- Comprehensive audit + remediation needed
- Large refactor with separable domains
- Time-sensitive delivery with independent work streams

## 8. When Not to Use Multi-Agent

- Simple single-file changes
- Requirements are unclear or unstable
- High interdependency with low decomposition potential
- Early experimentation/prototyping phases

## 9. Integration Checkpoints

- Pre-merge: each agent reports domain status (green/red + evidence).
- Pre-release: cross-domain checks pass (security, performance, tests).
- Post-merge: smoke tests run on integrated branch.
