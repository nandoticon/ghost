# Workflow: debug-issue

Purpose: Systematically identify and fix bugs with repeatable, time-boxed steps.

Total estimate: ~130 minutes (excluding CI/runtime wait and escalation delays).

## 1. Issue Reproduction (10 minutes)

Actions:
- Read error report or bug description.
- Attempt to reproduce the issue.
- Document exact steps to reproduce.
- Identify affected environment (dev/staging/prod).
- Determine severity (critical/high/medium/low).

Output:
- `reproduction-steps.md`

Decision point:
- If non-reproducible, add instrumentation and capture more context before continuing.

## 2. Error Analysis (15 minutes)

Actions:
- Collect error messages and stack traces.
- Check browser console for frontend issues.
- Check server logs for backend issues.
- Review recent changes (`git log` and related diffs).
- Identify exact error location (file + line).

Output:
- `error-analysis.md`

## 3. Hypothesis Formation (10 minutes)

Actions:
- Analyze code around the failing location.
- Form 2-3 root-cause hypotheses.
- Prioritize hypotheses by likelihood and impact.
- Define tests/observations to validate each hypothesis.

Output:
- `hypotheses.md`

## 4. Investigation (30 minutes)

Actions:
- Add targeted logging/debug statements.
- Use Antigravity browser for frontend issues.
- Run focused test cases.
- Check database state and query behavior.
- Verify API requests/responses.
- Test hypotheses one by one.

Output:
- `investigation-findings.md`

Decision point:
- If evidence invalidates all hypotheses, return to step 3 and generate new hypotheses.

## 5. Root Cause Identification (10 minutes)

Actions:
- Confirm the actual root cause with evidence.
- Explain why the bug occurred.
- Search for similar patterns elsewhere in codebase.
- Document confirmed root cause.

Output:
- `root-cause.md`

## 6. Fix Implementation (20 minutes)

Actions:
- Implement the fix.
- Ensure fix does not break adjacent functionality.
- Add defensive checks (validation/null handling/guards) where appropriate.
- Remove temporary debugging code.

Output:
- Fix code

## 7. Testing (20 minutes)

Actions:
- Re-test the exact bug scenario.
- Run existing tests for regression safety.
- Add a new regression test for recurrence prevention.
- Test edge cases.
- Verify in browser when applicable.

Output:
- Test results + new tests

## 8. Code Review (10 minutes)

Actions:
- Review fix for code quality standards.
- Validate error handling behavior.
- Assess security implications.
- Check performance impact.

Output:
- Reviewed code

## 9. Documentation (5 minutes)

Actions:
- Document bug and fix in relevant comments/docs.
- Update related documentation.
- Add CHANGELOG entry if applicable.
- Create post-mortem for critical bugs.

Output:
- Documentation updates

## Parallel Investigations

When multiple hypotheses exist:
- Spawn multiple agents via Agent Manager.
- Assign one hypothesis per agent.
- Require each agent to return evidence and pass/fail conclusion.
- Merge findings before choosing fix path.

## Escalation Points

Escalate to human immediately if:
- Security vulnerability is detected.
- Data corruption risk exists.
- Production access is required.
- No solution is found after 60 minutes of active debugging.

## Decision Tree

```text
Is error frontend or backend?
├─ Frontend
│  ├─ JavaScript error -> Check console, component state
│  ├─ Rendering issue -> Check styles, responsive design
│  └─ API error -> Check network tab, API response
└─ Backend
   ├─ API error -> Check request validation, server logs
   ├─ Database error -> Check query, migrations, constraints
   └─ Logic error -> Check business logic, data flow
```
