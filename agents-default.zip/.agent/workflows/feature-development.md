# Workflow: feature-development

Purpose: End-to-end workflow for building new features from requirements to deployment.

Total estimate: ~170 minutes (excluding waiting time for approvals, CI, and deployment windows).

## 1. Requirements Analysis (5 minutes)

Actions:
- Parse user story or feature request.
- Extract functional requirements.
- Identify technical constraints.
- List acceptance criteria.
- Ask clarifying questions if needed.

Output:
- `requirements-document.md`

Decision point:
- If requirements are ambiguous, pause and resolve open questions before step 2.

## 2. Technical Design (10 minutes)

Actions:
- Design database schema changes.
- Plan required API endpoints.
- Design component hierarchy.
- Identify reusable components.
- Plan state management approach.
- Enumerate edge cases and error scenarios.

Output:
- `technical-design.md`

Human approval point:
- Approve technical design before implementation continues.

Decision point:
- If approval is not granted, revise design and re-submit.

## 3. Database Implementation (15 minutes)

Actions:
- Create Prisma/Drizzle schema updates.
- Generate migration files.
- Run migrations locally.
- Add seed data for testing.
- Test database operations.

Output:
- Migration files + seed data

## 4. Backend Implementation (30 minutes)

Actions:
- Create API routes or tRPC procedures.
- Add input validation with Zod.
- Implement business logic.
- Add robust error handling.
- Write unit tests.
- Document API endpoints.

Output:
- Backend code + tests

## 5. Frontend Implementation (45 minutes)

Actions:
- Create React components.
- Add forms with validation.
- Implement data fetching.
- Add loading and error states.
- Style with Tailwind CSS.
- Ensure responsive behavior.
- Write component tests.

Output:
- Frontend code + tests

## 6. Integration (15 minutes)

Actions:
- Connect frontend and backend.
- Test end-to-end user flows.
- Verify error handling paths.
- Test edge cases.
- Check responsive behavior.
- Verify accessibility (a11y).

Output:
- Integrated feature

Human approval point:
- Approve feature implementation before browser testing and release readiness checks.

## 7. Browser Testing (20 minutes)

Actions:
- Use Antigravity browser automation.
- Test feature in an actual browser runtime.
- Verify UI rendering accuracy.
- Test core user interactions.
- Validate mobile responsiveness.
- Fix issues discovered in-browser.

Output:
- Browser test results

Decision point:
- If browser tests fail, return to steps 5-6 as needed, then re-run step 7.

## 8. Code Review and Optimization (15 minutes)

Actions:
- Run security checks.
- Verify code quality standards.
- Optimize performance hotspots.
- Validate error handling quality.
- Check test coverage thresholds.

Output:
- Optimized code

Decision point:
- If quality/security gates fail, return to relevant implementation step and repeat review.

## 9. Documentation (10 minutes)

Actions:
- Update README if needed.
- Document new API endpoints.
- Add inline comments only for complex logic.
- Create user-facing docs when required.

Output:
- Updated documentation

## 10. Pre-Deployment Checklist (5 minutes)

Checklist:
- [ ] All tests passing
- [ ] No console errors or warnings
- [ ] Security checks passed
- [ ] Performance acceptable
- [ ] Mobile responsive
- [ ] Accessibility verified
- [ ] Documentation updated

Output:
- Deployment-ready code

Human approval point:
- Approve deployment after checklist completion.

## Parallel Execution Plan

Rules:
- Steps 3 and 4 can run in parallel (database and backend tracks).
- Step 5 can start once step 2 is complete.
- Use Agent Manager to run multiple agents for parallel tracks.

Recommended orchestration:
1. Main agent completes steps 1-2.
2. Parallel agents execute steps 3, 4, and 5 with shared API/schema contracts.
3. Main agent integrates and drives steps 6-10.

## Artifacts Generated

- `requirements-document.md`
- `technical-design.md`
- migration files
- backend code
- frontend code
- tests
- documentation
- deployment checklist
