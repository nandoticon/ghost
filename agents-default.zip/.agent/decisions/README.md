# Architecture Decisions (ADR)
Document significant technical choices here following the ADR format.
