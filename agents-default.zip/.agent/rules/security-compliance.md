# Security and Compliance Rules for Gemini 3 Agents (2026 Web Standards)

This file defines mandatory rules for all Gemini 3 agents generating, reviewing, or refactoring code in this project.

Status: REQUIRED

Scope: Backend APIs, frontend web apps, infrastructure code, CI/CD, and data workflows.

Security baseline:
- OWASP Top 10 (2021+) and OWASP ASVS Level 2 controls must be applied by default.
- Privacy-by-design and secure-by-default patterns are required in every change.
- If a requirement conflicts with feature speed, security/compliance wins.

## 1. Security Standards

### 1.1 Input Validation and Injection Prevention

Rules:
- Treat all external input as untrusted (request body/query/path/headers/cookies/webhooks/files/messages).
- Validate and normalize input at trust boundaries using schemas (Zod/Joi/Valibot or equivalent).
- Reject unknown fields (`additionalProperties: false` style behavior).
- Encode output per context (HTML, URL, JS, CSS, SQL, shell).

Must prevent:
- XSS
- SQL/NoSQL injection
- Command injection
- Path traversal
- SSRF via user-provided URLs

Avoid:
```typescript
// BAD: XSS sink
element.innerHTML = userComment;

// BAD: SQL injection
await db.query(`SELECT * FROM users WHERE email = '${email}'`);

// BAD: command injection
exec(`tar -czf backup.tgz ${userPath}`);
```

Use:
```typescript
// GOOD: safe DOM update
element.textContent = userComment;

// GOOD: parameterized query
await db.query("SELECT * FROM users WHERE email = $1", [email]);

// GOOD: spawn with fixed command and validated args
const safePath = validatePath(userPath);
spawn("tar", ["-czf", "backup.tgz", safePath], { shell: false });
```

SSRF control pattern:
```typescript
// GOOD: allowlist protocol + host before outbound fetch
const url = new URL(inputUrl);
if (url.protocol !== "https:" || !ALLOWED_HOSTS.has(url.hostname)) {
  throw new Error("Blocked outbound URL");
}
```

### 1.2 Authentication and Authorization

Rules:
- Authentication and authorization are separate checks; never combine implicitly.
- Enforce authorization server-side on every protected endpoint.
- Default to deny if policy is missing.
- Prefer OAuth 2.1 / OIDC for delegated auth and enterprise SSO.
- For session auth: `HttpOnly`, `Secure`, `SameSite=Lax|Strict`, short idle timeout, rotation on privilege changes.
- For JWT: asymmetric signing (`RS256`/`ES256`), short expiration, key rotation with `kid`, strict audience/issuer validation.

Required authorization pattern:
```typescript
// GOOD: explicit policy check
if (!authz.can(currentUser, "invoice:read", invoice.orgId)) {
  return res.status(403).json({ error: "Forbidden" });
}
```

Avoid:
- Trusting client-side role flags.
- Long-lived bearer tokens without rotation/revocation.
- Returning different auth failure messages that aid account enumeration.

### 1.3 Secrets and Sensitive Configuration

Rules:
- Never hardcode API keys, passwords, private keys, tokens, DSNs, or encryption keys.
- Use environment variables plus managed secret stores (Vault, AWS Secrets Manager, GCP Secret Manager, Azure Key Vault).
- Validate required env vars at startup and fail closed.
- Rotate secrets regularly and immediately after incident response.
- Block commits containing secrets with pre-commit and CI secret scanning.

Avoid:
```typescript
const STRIPE_SECRET = "sk_live_123"; // BAD
```

Use:
```typescript
const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY;
if (!STRIPE_SECRET) throw new Error("Missing STRIPE_SECRET_KEY");
```

### 1.4 API Protection Controls

Rules:
- Rate limit by IP + account + route class (auth endpoints stricter than read endpoints).
- Add anti-automation controls for login/signup/password reset (cooldowns, captcha/challenge, anomaly detection).
- Implement CSRF protection for cookie-based auth (synchronizer token or double-submit).
- Enforce request size limits and strict content types.
- Use idempotency keys for payment/order write endpoints.

Express/Fastify control example:
```typescript
// Example defaults for state-changing API routes
rateLimit({ windowMs: 60_000, max: 60 });
csrfProtection();
enforceContentType("application/json");
```

### 1.5 Secure HTTP Headers and Transport

Rules:
- TLS 1.3 in transit for public endpoints.
- HTTPS redirect enforced; no mixed content.
- Set secure headers globally:
  - `Content-Security-Policy` (nonce/hash based; avoid `unsafe-inline`)
  - `Strict-Transport-Security` (`max-age=63072000; includeSubDomains; preload`)
  - `X-Content-Type-Options: nosniff`
  - `X-Frame-Options: DENY` (or `frame-ancestors` in CSP)
  - `Referrer-Policy: strict-origin-when-cross-origin`
  - `Permissions-Policy` with least privilege
  - `Cross-Origin-Resource-Policy` / `Cross-Origin-Opener-Policy` where applicable

Helmet-style baseline:
```typescript
app.use(helmet({
  hsts: { maxAge: 63072000, includeSubDomains: true, preload: true },
  contentSecurityPolicy: {
    useDefaults: true,
    directives: { "script-src": ["'self'"] }
  },
  frameguard: { action: "deny" }
}));
```

### 1.6 OWASP Top 10 Auto-Application Checklist

Gemini 3 agents must automatically evaluate each change against:
1. Broken access control
2. Cryptographic failures
3. Injection
4. Insecure design
5. Security misconfiguration
6. Vulnerable/outdated components
7. Identification and authentication failures
8. Software and data integrity failures
9. Security logging/monitoring failures
10. SSRF

If any risk is found:
- Flag it in review.
- Propose a secure patch.
- Add/adjust tests to prevent regression.

## 2. Data Protection and Privacy Compliance

### 2.1 Encryption and Key Management

Rules:
- Encrypt sensitive data at rest with strong modern ciphers (AES-256-GCM or platform-managed equivalent).
- Encrypt all external/internal service traffic in transit (TLS 1.3 preferred; TLS 1.2 only for legacy exceptions with risk sign-off).
- Separate encryption keys from data, with key rotation and audit trails.

### 2.2 Password and Credential Handling

Rules:
- Hash passwords with Argon2id (preferred) or bcrypt with strong cost factors.
- Unique per-password salts are mandatory.
- Optional pepper stored in secret manager, not in code or DB.

Avoid:
```typescript
// BAD
const hash = crypto.createHash("sha256").update(password).digest("hex");
```

Use:
```typescript
// GOOD (example)
const hash = await argon2.hash(password, {
  type: argon2.argon2id,
  memoryCost: 65536,
  timeCost: 3,
  parallelism: 1
});
```

### 2.3 GDPR/CCPA Operational Rules

Rules:
- Data minimization: collect only fields required for a defined business purpose.
- Purpose limitation: prohibit reuse of personal data outside declared use.
- Consent and preference tracking for processing categories when required.
- Data subject rights workflows required:
  - Access/export
  - Correction
  - Deletion/erasure
  - Opt-out (sale/share/targeted ads where applicable)
- Define and enforce retention windows by data type.
- Implement deletion workflow across primary DB, caches, search indexes, analytics sinks, and backups (with documented backup expiration behavior).

Retention/deletion example policy:
```text
Auth logs: 90 days
Billing records: 7 years (legal basis)
Inactive account profile data: delete or anonymize after 24 months
```

### 2.4 Security Logging and Monitoring

Rules:
- Log security-relevant events: auth success/failure, permission denials, token/key events, admin actions, policy changes, suspicious traffic.
- Never log secrets, full tokens, passwords, raw PII, card data, or full session identifiers.
- Use structured logs with correlation/request IDs.
- Return generic user-facing errors while preserving detailed internal telemetry.

Avoid:
```typescript
logger.error({ token, password, ssn, error }); // BAD
res.status(500).send(error.stack); // BAD
```

Use:
```typescript
logger.error({ errorId, route: req.path, userId: safeUserId, err: sanitizeError(error) });
res.status(500).json({ errorId, message: "Internal Server Error" });
```

## 3. Dependency and Supply Chain Management

Rules:
- Pin dependency versions and commit lock files (`package-lock.json`, `pnpm-lock.yaml`, `poetry.lock`, `Cargo.lock`, etc.).
- Run automated vulnerability scans in CI on every PR and on a daily schedule.
- Fail CI on critical/high vulnerabilities unless a documented temporary exception exists.
- Generate/update SBOM (CycloneDX/SPDX) for release artifacts where feasible.
- Verify provenance/signatures for critical packages and container images when tooling supports it.
- Prefer actively maintained libraries with clear security response processes.
- Remove unused dependencies promptly.

Agent behavior:
- Suggest updates when security patches are available.
- Include upgrade impact notes and migration risks.
- Avoid broad major-version upgrades unless requested.

## 4. Code Review Automation Rules (Pre-Commit and PR)

Gemini 3 agents must flag before commit:
- String-built SQL/NoSQL queries
- `innerHTML`/unsafe template rendering of untrusted content
- `eval`, `Function`, unsafe deserialization, and shell execution with interpolated input
- Missing authorization checks on protected resources
- Missing rate limit/CSRF controls on state-changing endpoints
- Sensitive data in logs/responses/errors
- Weak crypto or custom cryptography
- Hardcoded secrets or tokens in code/tests/config
- Missing error handling that leaks internals
- Dependencies with known exploitable CVEs

When flagging, agents must:
1. Explain the risk in one sentence.
2. Provide a secure alternative code snippet.
3. Recommend a regression test.

## 5. Secure Patterns Library (Follow vs Avoid)

### 5.1 Error Responses
```typescript
// AVOID
return res.status(500).json({ error: err.message, stack: err.stack });

// FOLLOW
const errorId = crypto.randomUUID();
logger.error({ errorId, err });
return res.status(500).json({ error: "Internal Server Error", errorId });
```

### 5.2 SQL Access
```typescript
// AVOID
const q = `SELECT * FROM orders WHERE id = ${req.params.id}`;

// FOLLOW
const q = "SELECT * FROM orders WHERE id = $1";
const row = await db.query(q, [req.params.id]);
```

### 5.3 Auth Middleware
```typescript
// AVOID: auth check without authorization
if (!req.user) return res.status(401).end();

// FOLLOW: auth + policy
if (!req.user) return res.status(401).end();
if (!authz.can(req.user, "orders:read", order.orgId)) return res.status(403).end();
```

## 6. Minimum Done Criteria for Security/Compliance

A task is not complete unless all are true:
1. Input validation and output encoding are present.
2. Authn/authz checks are enforced server-side.
3. No secrets are hardcoded; env and secret store usage is validated.
4. OWASP Top 10 review is performed with no unaddressed critical findings.
5. Logging avoids sensitive data and supports incident investigation.
6. Dependency scan passes or exceptions are documented with expiry.
7. Tests include at least one negative/security case for changed attack surface.

Non-compliance requires explicit documented exception and owner approval.
