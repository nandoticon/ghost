# Technology Stack and Framework Rules for Gemini 3 Agents (2026 Standards)

This file defines the approved stack and decision rules for modern 2026 web development in this project.

Status: REQUIRED

Scope: frontend, backend, APIs, infrastructure, CI/CD, and observability.

## 1. Frontend Standards

### 1.1 Required Defaults

| Category | Standard | Rule |
| :--- | :--- | :--- |
| Framework | React 19+ | Use Server Components by default where supported |
| Full-stack framework | Next.js 15+ | Use App Router for SSR/ISR and server actions |
| Language | TypeScript | Required for all new code (strict mode) |
| Styling | Tailwind CSS | Required for UI styling and design tokens |
| Component library | Shadcn/ui | Preferred for accessible reusable components |
| Data fetching/cache | TanStack Query | Default client-side async state management |
| State management | Zustand or Jotai | Use Redux only with explicit justification |
| Unit tests | Vitest | Required for component and utility tests |
| E2E tests | Playwright | Required for critical user journeys |

### 1.2 Frontend Enforcement Rules

Rules:
- New UI modules must be TypeScript (`.ts`/`.tsx`).
- Default to Server Components; use Client Components only when interactivity/browser APIs require them.
- Keep server/client boundaries explicit (`"use client"` only when necessary).
- Centralize query keys and API hooks when using TanStack Query.
- Avoid Redux boilerplate unless app complexity and debugging requirements justify it.

## 2. Backend Standards

### 2.1 Required Defaults

| Category | Standard | Rule |
| :--- | :--- | :--- |
| Runtime | Node.js 22+ | Required for all backend services |
| HTTP framework | Express or Fastify | Fastify preferred for high throughput |
| API layer | tRPC | Default for internal type-safe APIs |
| Database | PostgreSQL | Default relational datastore |
| Cache/session | Redis | Required for caching, sessions, rate-limit stores |
| ORM/query layer | Prisma or Drizzle | Drizzle for SQL-control/perf, Prisma for DX |
| Validation | Zod | Required at all input boundaries |
| Logging | Pino or Winston | Structured JSON logs only |

### 2.2 Backend Enforcement Rules

Rules:
- Validate request input and environment config with Zod schemas.
- Keep API contracts typed end-to-end (tRPC preferred for internal clients).
- Use repository/service boundaries instead of ORM access in route handlers.
- Route handlers must not contain business rules longer than simple orchestration.

## 3. Build, Deploy, and Observability

### 3.1 Build and Local Runtime

Rules:
- Use Vite for SPA/frontend package builds.
- Use Docker for containerized runtime parity.
- Use Docker Compose for local multi-service development.

### 3.2 CI/CD

Rules:
- Use GitHub Actions or GitLab CI pipelines.
- CI must run: typecheck, lint, unit tests, integration tests, and security scans.
- Block merges on failing required checks.

### 3.3 Deployment Targets

Preferred targets:
- Next.js/full-stack web: Vercel (primary), Netlify (alternative).
- API/services and workers: Railway (primary), other managed container hosts by exception.

### 3.4 Monitoring and Product Analytics

Rules:
- Use Sentry for exception and performance monitoring.
- Use PostHog or Plausible for product analytics (choose based on privacy/data-hosting requirements).

## 4. Development Tooling Standards

Rules:
- ESLint + Prettier are mandatory and CI-enforced.
- Husky hooks required for pre-commit and commit-msg checks.
- Commitlint required for Conventional Commits.
- Semantic Versioning (SemVer) required for releases.
- Conventional commit format required: `feat:`, `fix:`, `refactor:`, `docs:`, `test:`, `chore:`.

Commit examples:
```text
feat(auth): add oidc callback validation
fix(api): prevent null orgId in invoice query
refactor(ui): split dashboard widget renderer
```

## 5. When to Use What (Decision Rules)

### 5.1 App Type Selection

1. Need SEO, SSR, streaming, or server actions?
- Use Next.js 15+.

2. Internal tool/dashboard without SSR requirements?
- Use Vite + React SPA.

3. API-only backend (no web rendering)?
- Use Express or Fastify service.

### 5.2 Real-Time Features

Rules:
- Use Socket.io for custom bi-directional events and fine-grained room semantics.
- Use Supabase Realtime for managed realtime backed by Postgres change feeds.

### 5.3 File Uploads

Rules:
- Use S3-compatible object storage only:
  - AWS S3
  - Cloudflare R2
  - Supabase Storage
- Do not persist user file blobs on app containers/local disks.

### 5.4 Background Jobs

Rules:
- Use BullMQ for queue-first job processing with Redis.
- Use Inngest for event-driven workflow orchestration/serverless-friendly flows.

### 5.5 Authentication

Rules:
- Use Clerk for fast managed auth and enterprise SSO rollout.
- Use Supabase Auth for Postgres-centric stacks.
- Use Auth.js when custom provider flexibility is needed in Next.js.

## 6. Decision Trees

### 6.1 Architecture Decision Tree

1. Is SSR/SEO a hard requirement?
- Yes -> Next.js 15+.
- No -> Go to Step 2.

2. Is this strictly client-rendered product UI or internal admin?
- Yes -> Vite + React.
- No -> Next.js 15+.

3. Is API consumed mainly by first-party TypeScript clients?
- Yes -> tRPC.
- No -> Express/Fastify REST + typed OpenAPI contracts.

4. Do you need managed realtime from DB events?
- Yes -> Supabase Realtime.
- No -> Socket.io for custom channels/protocol.

5. Are workloads long-running/retry-heavy?
- Yes -> BullMQ queues.
- No -> Inngest event workflows or simple cron workers.

### 6.2 State/Data Decision Tree

1. Is data server-owned and async (API/cache/sync states)?
- Yes -> TanStack Query.

2. Is state local UI/global app state not suited for query cache?
- Yes -> Zustand or Jotai.

3. Need complex enterprise-style reducers, time-travel debugging, or strict event-sourcing integration?
- Yes -> Redux (exception path, requires rationale).

## 7. Trade-offs Reference

### 7.1 Next.js vs Vite

- Next.js advantages: SSR/ISR, routing, server actions, strong full-stack conventions.
- Next.js costs: server/client boundary complexity, higher framework coupling.
- Vite advantages: faster iteration for pure SPA, minimal runtime abstraction.
- Vite costs: no built-in SSR primitives by default.

### 7.2 Fastify vs Express

- Fastify advantages: higher throughput, schema-first ecosystem, lower overhead.
- Fastify costs: smaller plugin familiarity in some teams.
- Express advantages: broad ecosystem familiarity and simpler onboarding.
- Express costs: more manual performance/security guardrails.

### 7.3 Drizzle vs Prisma

- Drizzle advantages: SQL-first control, lean runtime, predictable queries.
- Drizzle costs: more manual modeling effort.
- Prisma advantages: strong DX, migrations/introspection tooling, fast team onboarding.
- Prisma costs: abstraction overhead in complex query tuning scenarios.

### 7.4 PostHog vs Plausible

- PostHog advantages: feature-rich product analytics and event tooling.
- PostHog costs: more configuration and data governance overhead.
- Plausible advantages: lightweight, privacy-centric analytics.
- Plausible costs: fewer advanced behavioral analysis features.

## 8. Done Criteria for Stack Compliance

A change is stack-compliant only when:
1. Chosen technologies match the decision rules above.
2. TypeScript, linting, formatting, and tests pass in CI.
3. Observability (Sentry + analytics selection) is configured for new services.
4. Deviations (e.g., Redux usage) include explicit rationale in PR notes or ADR.
