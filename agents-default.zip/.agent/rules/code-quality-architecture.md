# Code Quality and Architecture Rules for Gemini 3 Agents (2026 Standards)

This file defines mandatory architecture, quality, testing, documentation, and performance rules for all generated and reviewed code.

Status: REQUIRED

Scope: frontend, backend, shared libraries, data access, and CI-enforced code quality.

## 1. Architecture Patterns

### 1.1 Clean/Hexagonal Architecture (Mandatory)

Rules:
- Keep domain logic framework-agnostic.
- Depend inward: UI -> Application -> Domain; Infrastructure points to Domain/Application interfaces.
- No direct DB/API calls in controllers/components.
- No UI concerns inside domain services.

Required layer boundaries:
- `UI/Interface`: route handlers, controllers, components, presenters.
- `Application`: use-cases, orchestration, transactions, policy coordination.
- `Domain`: entities, value objects, domain services, business rules.
- `Infrastructure`: repositories, ORM adapters, external API adapters, queues, filesystem.

Avoid:
```typescript
// BAD: route directly using ORM and business rules
app.post("/users", async (req, res) => {
  const user = await prisma.user.create({ data: req.body });
  if (user.plan === "enterprise") sendWelcomeCredit(user);
  res.json(user);
});
```

Use:
```typescript
// GOOD: route -> use case -> repository abstraction
app.post("/users", async (req, res) => {
  const result = await registerUserUseCase.execute(req.body);
  res.status(201).json(result);
});
```

### 1.2 Dependency Injection and Inversion of Control

Rules:
- Constructors receive interfaces, not concrete infrastructure types.
- Composition root wires implementations once (startup/bootstrap).
- No `new ConcreteRepository()` inside business services.

Pattern:
```typescript
export interface UserRepository {
  save(user: User): Promise<User>;
}

export class RegisterUserUseCase {
  constructor(private readonly users: UserRepository) {}
  async execute(input: RegisterUserInput) {
    return this.users.save(User.create(input));
  }
}
```

### 1.3 Repository Pattern (Data Access)

Rules:
- Repositories hide ORM/query details from application/domain layers.
- Return domain objects or stable DTOs, never ORM internals.
- Keep query logic centralized and testable.

### 1.4 SOLID Auto-Application

Agents must enforce:
- `S`: one reason to change per module.
- `O`: extension via strategies/polymorphism over branching growth.
- `L`: subtype contracts preserved.
- `I`: small targeted interfaces.
- `D`: high-level modules depend on abstractions.

## 2. Code Quality Standards

### 2.1 Hard Thresholds (Fail if Violated)

| Metric | Threshold | Enforcement |
| :--- | :--- | :--- |
| Max function length | 50 lines | Refactor into helpers/use-cases |
| Max file length | 300 lines | Split by responsibility |
| Cyclomatic complexity | 10 | Simplify branches/strategy pattern |
| Duplication (DRY) | 3rd repetition triggers extraction | Move to shared util/module |

### 2.2 Naming and Self-Documenting Code

Rules:
- Use intention-revealing names: `calculateInvoiceTotal` not `calc`.
- Booleans must read as predicates (`is`, `has`, `can`, `should`).
- Avoid ambiguous abbreviations except well-known domain acronyms.

Avoid:
```typescript
const d = getD(u);
```

Use:
```typescript
const discountAmount = getDiscountAmount(user);
```

### 2.3 Type Safety and API Contracts

Rules:
- TypeScript strict mode required.
- Public functions/classes/interfaces require TypeScript types and JSDoc.
- Ban `any` in public APIs; use `unknown` + narrowing when needed.
- Validate external input with schemas before entering business logic.

JSDoc example:
```typescript
/**
 * Creates a subscription and returns the billing summary.
 * @throws {ValidationError} If input fails schema validation.
 */
export async function createSubscription(input: CreateSubscriptionInput): Promise<BillingSummary> {
  // ...
}
```

### 2.4 Formatting and Static Analysis

Rules:
- Prettier and ESLint are mandatory and blocking in CI.
- No merges with lint/type/test failures.
- Import order, unused vars, and dead code must be cleaned before commit.

## 3. Testing Requirements

### 3.1 Coverage and Scope

Rules:
- Minimum 80% line and branch coverage for business logic (`domain` + `application`).
- Unit tests required for all pure functions and domain rules.
- Integration tests required for API endpoints and repository adapters.
- E2E tests required for critical user flows (auth, checkout/payment, account lifecycle).

### 3.2 Edge Cases and Error Conditions

Each changed unit must test:
- happy path
- validation failure
- boundary/edge input
- dependency failure (timeout/db down/third-party error)
- authorization/permission denial where applicable

### 3.3 TDD Guidance

Rules:
- Use TDD for non-trivial logic (new business rules, pricing, permissions, state transitions).
- For simple CRUD wiring, test-after is acceptable if coverage and negative cases are met.

## 4. Documentation Standards

### 4.1 Code-Level Documentation

Rules:
- Every public function/class/type must include concise documentation.
- Inline comments allowed only for non-obvious decisions or constraints.
- Do not comment trivial code.

### 4.2 Project Documentation

Required artifacts:
- `README.md` includes setup, run/test commands, usage, and architecture overview.
- API documentation includes request/response examples and error formats.
- ADRs required for major architectural or technology choices.

ADR minimum template:
```text
Title
Status
Context
Decision
Consequences
Alternatives considered
```

## 5. Performance Guidelines

### 5.1 Web Performance Budgets

Rules:
- Core Web Vitals targets:
  - LCP <= 2.5s (p75)
  - INP <= 200ms (FID legacy references allowed for backward dashboards)
  - CLS <= 0.1

### 5.2 Frontend Performance Patterns

Rules:
- Lazy-load route-level and heavy components.
- Use code splitting for large bundles.
- Avoid shipping unused polyfills/libraries.
- Optimize images, fonts, and critical rendering path.

### 5.3 Data and Backend Performance

Rules:
- Pagination required for large datasets (default + max page size enforced).
- Avoid N+1 queries via joins, batching, or loader patterns.
- Add indexes for frequently filtered/sorted fields.
- Set query timeouts and monitor slow-query logs.
- Cache high-read data with clear TTL/invalidations (Redis/CDN).

Pagination example:
```typescript
const limit = Math.min(Number(req.query.limit ?? 20), 100);
const offset = Number(req.query.offset ?? 0);
```

## 6. Agent Review Checklist (Pre-Commit/PR)

Agents must block or flag changes when:
1. Any architecture boundary is violated.
2. Function/file/complexity thresholds are exceeded.
3. Public API lacks types or JSDoc.
4. Tests are missing for changed logic or coverage target drops below 80%.
5. Docs are not updated for public API or architectural changes.
6. Performance regressions are introduced without justification.

## 7. Done Criteria

A task is complete only when all are true:
1. Architecture boundaries are preserved.
2. Code meets all hard thresholds.
3. Required tests are present and passing.
4. Required documentation is updated.
5. Lint/type checks pass and formatting is clean.
6. Performance-sensitive paths include appropriate optimizations.
