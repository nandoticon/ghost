# Project Context
Domain-specific knowledge, glossaries, and team conventions.
