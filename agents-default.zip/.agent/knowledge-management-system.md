# Knowledge Management System (KMS)

Purpose: Enable agents to learn from each project and build reusable knowledge over time.

## 1. Knowledge Categories

### 1.1 Code Patterns

Location: `.agent/patterns/`

Capture reusable implementation patterns such as:
- authentication implementation
- API error handling
- form validation
- file upload
- real-time updates
- payment processing

Each pattern should include:
- problem solved
- code template
- usage instructions
- when to use vs alternatives
- example implementation

### 1.2 Common Issues and Solutions

Location: `.agent/solutions/`

For each solved issue, document:
- problem statement
- investigation process
- final solution
- prevention strategy
- links to related rules/skills/workflows

Examples:
- CORS issues
- database migration conflicts
- state management race conditions
- performance bottlenecks
- security vulnerabilities

### 1.3 Architecture Decisions

Location: `.agent/decisions/`

Use ADR format:
- Title
- Status (Proposed, Accepted, Deprecated, Superseded)
- Context
- Decision
- Consequences
- Alternatives considered

Examples:
- why tRPC vs REST
- PostgreSQL rationale
- Zustand vs Redux
- JWT vs session-based auth

### 1.4 Project-Specific Context

Location: `.agent/context/`

Maintain:
- business domain glossary
- user personas
- feature priorities
- technical constraints
- team conventions
- external integrations map

## 2. Learning Workflows

### After Completing a Feature

1. Review what worked well and what did not.
2. Save reusable patterns in `.agent/patterns/`.
3. Save novel solutions in `.agent/solutions/`.
4. Record key decisions in `.agent/decisions/`.
5. Update relevant skills/rules/workflows as needed.

### After Debugging an Issue

1. Document confirmed root cause.
2. Add issue and fix to `.agent/solutions/`.
3. Update rules to prevent recurrence if applicable.
4. Improve workflows based on debugging lessons.

### After Performance Optimization

1. Document optimization approach.
2. Record before/after metrics.
3. Add reusable optimization patterns to `.agent/patterns/`.
4. Update performance skill/workflow where needed.

## 3. Knowledge Retrieval

Before starting new tasks:
1. Check `.agent/patterns/` for reusable approaches.
2. Check `.agent/solutions/` for known issue classes.
3. Review `.agent/decisions/` for architectural constraints.
4. Review `.agent/context/` for domain conventions.
5. Apply prior learnings to avoid repeated mistakes.

## 4. Knowledge Sharing Between Agents

When multiple agents collaborate:
- Share new patterns through `.agent/patterns/`.
- Reference existing solutions for consistency.
- Follow established ADR decisions.
- Add cross-agent notes in shared workflow artifacts.

## 5. Knowledge Validation and Maintenance

Review periodically:
- Are stored patterns still valid?
- Are there better current solutions?
- Are ADRs still accurate?
- Deprecate outdated content and mark replacements.

## 6. Workflow Integration Rule

All workflows should:
1. Start by checking relevant knowledge artifacts.
2. End by updating knowledge when new information is created.
3. Reuse patterns when available.
4. Document newly discovered reusable patterns.

## 7. File Structure

```text
.agent/
├── patterns/
│   ├── README.md
│   ├── authentication.md
│   ├── error-handling.md
│   ├── file-upload.md
│   └── ...
├── solutions/
│   ├── README.md
│   ├── cors-issues.md
│   ├── migration-conflicts.md
│   └── ...
├── decisions/
│   ├── README.md
│   ├── 001-trpc-over-rest.md
│   ├── 002-database-choice.md
│   └── ...
└── context/
    ├── README.md
    ├── glossary.md
    ├── user-personas.md
    └── ...
```

## 8. Pattern Documentation Template

````markdown
# [Pattern Name]

## Problem
What problem does this pattern solve?

## Solution
How does this pattern solve it?

## Code Example
```txt
// Example code here
```

## When to Use
- Scenario 1
- Scenario 2

## When Not to Use
- Anti-pattern scenario

## Alternatives
- Alternative approach and trade-offs

## References
- Related skills
- Related workflows
- External documentation
````
