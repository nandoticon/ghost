# Skill: security-hardening

This skill applies proactive security hardening by default to all code changes. Treat this as an automatic checklist, not optional guidance.

## 1. Application Security

### 1.1 Input Validation and Sanitization

Rules:
- Validate all user input on client and server.
- Use Zod or Joi schemas at all API boundaries.
- Sanitize user-provided HTML with DOMPurify before rendering.
- Use parameterized queries only (no string-built SQL).
- Validate file uploads by MIME type, extension, max size, and content signature.
- Escape untrusted data before rendering.

Patterns:
```typescript
// Good: server validation
const schema = z.object({ email: z.string().email(), name: z.string().min(1) });
const parsed = schema.safeParse(req.body);
if (!parsed.success) return res.status(400).json({ error: "ValidationError" });
```

```typescript
// Good: SQL injection prevention
await db.query("SELECT * FROM users WHERE email = $1", [email]);
```

### 1.2 Authentication and Authorization

Rules:
- Use secure session management and rotation after privilege changes.
- Enforce strong password policy (length, complexity, breached-password checks if available).
- Add rate limiting to auth endpoints.
- Enforce HTTPS only and redirect HTTP -> HTTPS.
- Implement CSRF protection for cookie-based auth.
- Require MFA for sensitive operations (password/email/security changes, payouts).
- Set cookie flags: `httpOnly`, `secure`, `sameSite`.
- Implement proper logout by invalidating server-side sessions/tokens.
- Lock account or require step-up challenge after repeated failed attempts.

### 1.3 API Security

Rules:
- Implement API key rotation and expiration.
- Apply rate limits per endpoint and per user/client.
- Enforce request body size limits.
- Validate `Content-Type` for each endpoint.
- Configure CORS with explicit allowlists.
- Use API versioning (`/v1`, `/v2`).
- Use request signing for sensitive endpoints.
- Verify webhook signatures and enforce idempotency keys.

### 1.4 Data Protection

Rules:
- Encrypt sensitive data at rest.
- Use TLS 1.3 for data in transit.
- Use centralized key management with rotation.
- Hash passwords with bcrypt or argon2 only (never MD5/SHA1).
- Mask/redact sensitive values in logs.
- Anonymize user data for analytics where possible.
- Keep audit trails for sensitive operations.

### 1.5 Security Headers

Implement all headers:

```http
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline';
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Strict-Transport-Security: max-age=31536000; includeSubDomains
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(), microphone=(), camera=()
```

Implementation note:
- Keep CSP as strict as possible and remove `unsafe-inline` when nonce/hash-based policy is feasible.

### 1.6 Dependency Security

Rules:
- Run `npm audit`/`yarn audit` regularly in CI.
- Use Snyk or Dependabot for continuous vulnerability detection.
- Update dependencies on a regular cadence.
- Review dependency licenses for compliance.
- Minimize dependency count.
- Pin versions to reduce supply-chain risk.

### 1.7 Error Handling

Rules:
- Never expose stack traces to clients.
- Log errors securely without secrets/PII.
- Add frontend error boundaries.
- Return generic client error messages.
- Use Sentry (or equivalent) with data scrubbing.

Pattern:
```typescript
// Good: safe error response
logger.error({ err, requestId: req.id });
return res.status(500).json({ error: "InternalServerError", requestId: req.id });
```

### 1.8 Secrets Management

Rules:
- Never commit secrets to git.
- Use environment variables and secret managers.
- Rotate secrets regularly.
- Use AWS Secrets Manager / HashiCorp Vault (or platform equivalent).
- Ensure `.env` is in `.gitignore`.
- Use separate secrets per environment (dev/staging/prod).

## 2. Security Checklist for Every Feature

- [ ] All inputs validated and sanitized
- [ ] Authentication and authorization checked
- [ ] SQL injection prevention verified
- [ ] XSS prevention verified
- [ ] CSRF protection added
- [ ] Rate limiting implemented
- [ ] Error messages do not leak information
- [ ] Logging does not expose sensitive data
- [ ] HTTPS enforced
- [ ] Security headers configured

## 3. Automated Security Checks (Always Run)

The agent should automatically:
1. Scan for hardcoded secrets before commits.
2. Check for known vulnerable dependencies.
3. Verify security headers are set.
4. Flag insecure patterns (`eval`, `innerHTML`, `dangerouslySetInnerHTML`).
5. Suggest concrete security improvements in code review.

## 4. Auto-Apply Policy

When generating or reviewing code, the agent must:
1. Apply this checklist proactively without waiting for explicit prompts.
2. Block or flag critical security violations.
3. Provide safer alternative code patterns.
4. Add/require security-focused regression tests for changed attack surface.
