# Skill: fullstack-web-development

This skill enables Gemini agents to design, implement, test, and document production-grade full-stack features in modern 2026 web stacks.

## 1. Capabilities

### 1.1 Frontend Development

The agent can:
- Create responsive React components with TypeScript.
- Implement complex forms with `react-hook-form` + `zod`.
- Build data tables with sorting, filtering, and pagination.
- Create dashboards with charts/visualizations.
- Implement authentication flows (login, signup, password reset).
- Handle file uploads with progress tracking and failure recovery.
- Implement infinite scroll and virtualization for large lists.
- Add loading states, error boundaries, and toast notifications.

Implementation defaults:
- React 19+ with Server Components when applicable.
- Next.js App Router for full-stack apps.
- TanStack Query for client-side data fetching/caching.
- Shadcn/ui + Tailwind CSS for UI primitives and styling.

### 1.2 Backend Development

The agent can:
- Design RESTful and tRPC APIs.
- Implement CRUD operations with validation and typed contracts.
- Add auth middleware (JWT and session-based).
- Create database schemas and migrations (Prisma or Drizzle).
- Implement secure file upload handling.
- Add transactional email sending flows.
- Create background job processing pipelines.
- Implement webhook handlers with signature verification and idempotency.

### 1.3 Database Design

The agent can:
- Model normalized relational data.
- Create indexes for query performance.
- Implement soft deletes and audit trails.
- Use transactions for multi-step data integrity.
- Write efficient join queries and avoid N+1 patterns.

### 1.4 Integration Patterns

The agent can:
- Connect to third-party APIs with retries/timeouts and typed errors.
- Implement OAuth social login flows.
- Integrate Stripe payments/subscriptions.
- Integrate email services (Resend, SendGrid).
- Integrate object storage (AWS S3, Cloudflare R2, Supabase Storage).

## 2. Workflow for Full-Stack Features

When asked to build a feature, use this sequence:

1. Clarify requirements and user stories.
2. Design database schema.
3. Create API endpoints with validation.
4. Build frontend components.
5. Connect frontend to backend.
6. Add error handling and loading states.
7. Write tests for critical paths.
8. Document API and component usage.

Execution notes:
- Confirm auth rules, roles, and tenant boundaries before coding.
- Define success/failure states for each user action.
- Ship vertical slices (schema -> API -> UI -> tests) in small increments.

## 3. Decision Trees

### 3.1 API Style: REST vs tRPC

1. Is the client primarily TypeScript and first-party?
- Yes -> use tRPC for end-to-end typed procedures.
- No -> use REST + OpenAPI for broader compatibility.

2. Is external partner integration required?
- Yes -> REST with stable versioned endpoints.
- No -> tRPC preferred.

### 3.2 Data Fetching: Server Components vs TanStack Query

1. Is SEO/initial paint the priority and data can be rendered server-side?
- Yes -> fetch in Server Components.
- No -> use TanStack Query in client components.

2. Is near-real-time mutation state required (optimistic updates, retries, cache invalidation)?
- Yes -> TanStack Query.

### 3.3 Storage Choice for Uploads

1. Need S3 API compatibility?
- Yes -> AWS S3 or Cloudflare R2.

2. Already using Supabase heavily?
- Yes -> Supabase Storage.

### 3.4 Jobs and Webhooks

1. Does the task require retries/backoff/delayed jobs?
- Yes -> BullMQ (Redis-backed).

2. Is workflow event-driven and serverless-first?
- Yes -> Inngest.

3. Webhook endpoint receiving third-party events?
- Always verify signature + enforce idempotency key.

## 4. Code Templates

### 4.1 API Route with Validation (REST + Zod)

```typescript
import { z } from "zod";
import type { Request, Response } from "express";
import { userService } from "../services/user-service";

const createUserSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
});

export async function createUserHandler(req: Request, res: Response) {
  const parsed = createUserSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "ValidationError", issues: parsed.error.issues });
  }

  try {
    const user = await userService.create(parsed.data);
    return res.status(201).json(user);
  } catch (error) {
    req.log?.error({ error }, "createUserHandler failed");
    return res.status(500).json({ error: "InternalServerError" });
  }
}
```

### 4.2 CRUD Operations (Service + Repository)

```typescript
// service/user-service.ts
export async function updateUser(id: string, input: UpdateUserInput) {
  return db.$transaction(async (tx) => {
    const existing = await tx.user.findUnique({ where: { id, deletedAt: null } });
    if (!existing) throw new NotFoundError("User");
    return tx.user.update({ where: { id }, data: input });
  });
}

export async function softDeleteUser(id: string, actorId: string) {
  return db.user.update({
    where: { id },
    data: { deletedAt: new Date(), updatedBy: actorId },
  });
}
```

### 4.3 Protected Route Middleware (JWT + Session)

```typescript
import type { Request, Response, NextFunction } from "express";
import { verifyJwt } from "../lib/jwt";

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const bearer = req.headers.authorization?.replace("Bearer ", "");
  const sessionUser = (req as any).session?.user;
  const tokenUser = bearer ? verifyJwt(bearer) : null;
  const user = sessionUser ?? tokenUser;

  if (!user) return res.status(401).json({ error: "Unauthorized" });
  (req as any).user = user;
  return next();
}
```

### 4.4 React Component with Data Fetching (TanStack Query)

```tsx
"use client";

import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

async function fetchProjects() {
  const res = await fetch("/api/projects");
  if (!res.ok) throw new Error("Failed to fetch projects");
  return res.json() as Promise<Array<{ id: string; name: string }>>;
}

export function ProjectList() {
  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["projects"],
    queryFn: fetchProjects,
  });

  if (isLoading) return <div className="animate-pulse">Loading projects...</div>;
  if (isError) {
    toast.error("Could not load projects");
    return <div role="alert">{(error as Error).message}</div>;
  }

  return (
    <ul className="space-y-2">
      {data?.map((p) => (
        <li key={p.id} className="rounded border p-2">{p.name}</li>
      ))}
    </ul>
  );
}
```

### 4.5 Form with Validation (React Hook Form + Zod)

```tsx
"use client";

import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(12),
});
type SignupInput = z.infer<typeof signupSchema>;

export function SignupForm() {
  const form = useForm<SignupInput>({ resolver: zodResolver(signupSchema) });

  const onSubmit = form.handleSubmit(async (values) => {
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    if (!res.ok) throw new Error("Signup failed");
  });

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <input type="email" {...form.register("email")} />
      <input type="password" {...form.register("password")} />
      <button disabled={form.formState.isSubmitting}>
        {form.formState.isSubmitting ? "Creating..." : "Create account"}
      </button>
      {form.formState.errors.email && <p>{form.formState.errors.email.message}</p>}
    </form>
  );
}
```

### 4.6 Error Handling Pattern (Typed App Errors)

```typescript
export class AppError extends Error {
  constructor(
    public readonly code: "VALIDATION" | "NOT_FOUND" | "FORBIDDEN" | "INTERNAL",
    message: string,
    public readonly status = 500
  ) {
    super(message);
  }
}

export function toHttpError(error: unknown) {
  if (error instanceof AppError) return error;
  return new AppError("INTERNAL", "Unexpected error", 500);
}
```

## 5. Implementation Checklists

### 5.1 Frontend Feature Checklist
- Responsive layout complete (mobile/tablet/desktop).
- Loading/empty/error states implemented.
- Form validation covers client + server errors.
- Toast feedback added for async user actions.
- Error boundary wraps complex routes/pages.
- Large lists use pagination, infinite scroll, or virtualization.

### 5.2 Backend Feature Checklist
- Input schema validation at boundary.
- Auth middleware + authorization checks applied.
- CRUD endpoints include not-found/conflict handling.
- File upload constraints enforced (size/type/virus-scan pipeline if available).
- Background jobs/webhooks are idempotent.
- Logging includes correlation IDs and avoids sensitive data.

### 5.3 Database Checklist
- Keys and indexes defined for dominant read queries.
- Soft delete columns and audit metadata included where required.
- Transactions used for multi-table writes.
- Explain plan reviewed for complex queries.

## 6. Testing Guidance

Required minimums for delivered features:
- Unit tests for pure logic and validators.
- Integration tests for API endpoints and DB writes.
- E2E tests for critical flows (auth, checkout, upload, settings).
- Negative tests: invalid input, unauthorized access, external API failure.

## 7. Output Expectations

When completing a feature, provide:
1. Schema/migration summary.
2. API contract summary (routes/procedures, request/response).
3. Frontend component usage notes.
4. Test coverage and remaining risks.
