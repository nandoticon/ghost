# Skill: performance-optimization

This skill enables the agent to measure, diagnose, optimize, and verify frontend/backend performance with clear thresholds and repeatable patterns.

## 1. Frontend Performance

### 1.1 Core Web Vitals Optimization Targets

Required targets:
- LCP (Largest Contentful Paint): `< 2.5s`
- FID (First Input Delay): `< 100ms`
- CLS (Cumulative Layout Shift): `< 0.1`

Modern telemetry note:
- Also track INP (`< 200ms`) in production dashboards alongside FID.

#### LCP Optimization

Focus actions:
- Optimize images (WebP/AVIF, right dimensions, compression).
- Lazy-load below-the-fold media/components.
- Use CDN for static assets.
- Apply resource hints (`preload`, `prefetch`, `preconnect`) for critical resources.

#### FID Optimization

Focus actions:
- Minimize JavaScript execution time on initial load.
- Split large bundles with route/component-level code splitting.
- Move heavy computation to web workers.
- Defer non-critical JavaScript.

#### CLS Optimization

Focus actions:
- Set width/height or aspect-ratio for images/embeds.
- Avoid inserting content above already-rendered content.
- Prefer `transform`/`opacity` animations over layout-triggering properties.

### 1.2 Asset Optimization

Rules:
- Compress images (`sharp`, `imagemin`, or framework image pipelines).
- Use responsive images via `srcset`/`sizes`.
- Minify CSS/JS in production builds.
- Remove unused CSS (PurgeCSS/Tailwind purge).
- Enable tree-shaking and dead code elimination.
- Use font loading strategy (`font-display: swap`) and subset fonts.

### 1.3 React Performance

Rules:
- Use `React.memo` for expensive, stable-prop components.
- Use `useMemo`/`useCallback` only where profiling shows rerender cost.
- Use virtualization for large lists (`react-virtual`).
- Split large components and isolate state to reduce rerenders.
- Avoid defining unnecessary inline functions in hot render paths.
- Prefer React Server Components when possible.
- Add Suspense boundaries for async UI segmentation.

### 1.4 Network Optimization

Rules:
- Use HTTP/2 or HTTP/3 where available.
- Enable gzip/brotli for text-based responses.
- Use service workers for cache/offline strategy when appropriate.
- Implement request caching (ETag, cache-control, stale-while-revalidate).
- Reduce API payload size and over-fetching.
- Use GraphQL/tRPC patterns to fetch only required data.
- Implement optimistic updates for latency-sensitive mutations.

## 2. Backend Performance

### 2.1 Database Optimization

Rules:
- Add indexes for frequently filtered/joined/sorted columns.
- Use connection pooling (and external poolers when needed).
- Use Redis query caching for expensive reads.
- Eliminate N+1 queries with joins/includes/batching.
- Paginate large result sets with limits and cursors/offset rules.
- Prefer DB-level aggregation for heavy counting/grouping.
- Use read replicas for read-heavy workloads.

### 2.2 API Performance

Rules:
- Set response cache headers for cacheable routes.
- Add rate limiting to protect backend performance.
- Enable compression middleware.
- Batch DB operations when safe.
- Stream large responses instead of buffering entire payloads.
- Use GraphQL DataLoader pattern to coalesce repeated entity fetches.

### 2.3 Caching Strategy

Layers:
- Browser caching for static assets.
- CDN caching for global edge delivery.
- Redis caching for expensive queries and session-adjacent data.
- In-process memoization for deterministic expensive computations.

Requirement:
- Define explicit cache invalidation strategy (TTL + event-based invalidation).

### 2.4 Infrastructure Optimization

Rules:
- Use CDN for static assets (Cloudflare, Fastly, or equivalent).
- Enable horizontal scaling for stateless services.
- Use load balancers with health checks.
- Optimize Docker images with multi-stage builds.
- Monitor services with APM and infrastructure dashboards.

## 3. Performance Measurement

Use these tools:
- Lighthouse in Antigravity browser.
- Bundle analysis (`webpack-bundle-analyzer` or equivalent).
- React Profiler for render bottlenecks.
- Production CWV monitoring.
- Performance budgets in CI/CD.
- Time-series tracking for regression detection.

Minimum tracked metrics:
- LCP, FID, CLS, INP
- FCP, TTFB
- JS bundle size (initial and total)
- API p50/p95 latency
- Slow query p95 and cache hit rate

## 4. Optimization Workflow

1. Measure baseline performance.
2. Identify bottlenecks using profiler/trace data.
3. Prioritize fixes by impact/effort.
4. Implement changes incrementally.
5. Measure improvements after each change.
6. Document optimization decisions and trade-offs.

## 5. Performance Budgets

Default budgets (override only with explicit approval):
- Initial JS (compressed): `< 200KB`
- LCP: `< 2.5s`
- FID: `< 100ms`
- CLS: `< 0.1`
- Public API p95 latency: `< 300ms` for cacheable reads (service-dependent)

If a budget is exceeded:
- Block release or require approved exception with mitigation plan.

## 6. Before/After Patterns

### 6.1 Image Delivery

Before:
```tsx
<img src="/hero.png" />
```

After:
```tsx
<img
  src="/hero.avif"
  srcSet="/hero-640.avif 640w, /hero-1280.avif 1280w"
  sizes="(max-width: 768px) 100vw, 1280px"
  width="1280"
  height="720"
  loading="eager"
  decoding="async"
/>
```

### 6.2 Query Performance

Before:
```sql
SELECT * FROM orders WHERE user_id = $1 ORDER BY created_at DESC;
```

After:
```sql
CREATE INDEX IF NOT EXISTS idx_orders_user_created ON orders(user_id, created_at DESC);
SELECT id, total, created_at FROM orders WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50;
```

### 6.3 React List Rendering

Before:
```tsx
{items.map((item) => <Row key={item.id} item={item} />)}
```

After:
```tsx
// Use react-virtual for large lists to render only visible rows.
```

## 7. Output Format for Optimization Tasks

When completing optimization work, provide:
1. Baseline metrics
2. Bottleneck findings
3. Changes made
4. Before/after metric comparison
5. Remaining risks and next actions
