# Skill: debug-troubleshoot

This skill gives the agent a systematic decision tree for diagnosing and fixing frontend, backend, database, network, and infrastructure issues.

## 1. Debugging Methodology

### 1.1 Problem Identification

Always start here:
1. Reproduce the error consistently.
2. Read error messages and stack traces fully.
3. Check browser console for frontend issues.
4. Check server logs for backend issues.
5. Identify scope: frontend, backend, database, network, or infrastructure.

If the issue cannot be reproduced:
- Gather exact steps, input data, environment, and timestamp.
- Check environment/config differences.
- Add targeted logging and retry with trace IDs.

### 1.2 Diagnostic Techniques

Use these methods by default:
- Add strategic `console.log` or debugger breakpoints.
- Browser DevTools:
  - Network tab for API calls
  - Console for errors/warnings
  - Application tab for local/session storage and cookies
  - Performance tab for bottlenecks
- Check database query logs and slow-query logs.
- Verify environment variables and runtime config.
- Reproduce API behavior via `curl` or Postman.
- Use React DevTools to inspect component props/state and rerenders.

## 2. Systematic Debugging Process

Follow these steps in order:
1. Read error message completely.
2. Identify file and line number.
3. Define expected behavior vs actual behavior.
4. Form a hypothesis for root cause.
5. Test hypothesis with one targeted change at a time.
6. Verify fix does not break related functionality.
7. Add regression tests to prevent recurrence.

Rules:
- Change one variable at a time.
- Keep notes of each experiment and outcome.
- Prefer root-cause fixes over symptom masking.

## 3. Master Decision Tree

### 3.1 Start Node

1. Is there a visible UI problem?
- Yes -> go to Frontend Tree.
- No -> continue.

2. Is an API call failing or returning wrong data?
- Yes -> go to Backend/API Tree.
- No -> continue.

3. Is data incorrect/missing/slow in persistence layer?
- Yes -> go to Database Tree.
- No -> continue.

4. Is request failing before app code (timeouts, DNS, TLS, CORS)?
- Yes -> go to Network/Infrastructure Tree.
- No -> go to Cross-Cutting Checks.

### 3.2 Frontend Tree

1. Console shows runtime error?
- Yes -> inspect stack trace, source map, failing component.
- No -> continue.

2. API data missing in UI?
- Check Network request/response status and payload.
- Validate auth headers/cookies.
- Inspect query cache/state (TanStack Query, Zustand/Jotai).

3. UI rendered incorrectly?
- Inspect element + computed styles.
- Check responsive breakpoints and CSS specificity.
- Validate layout shifts and async content placeholders.

4. State bug suspected?
- Confirm state update ordering and stale closures.
- Check async race conditions and cancellation logic.

### 3.3 Backend/API Tree

1. Status code class:
- `4xx` -> validate request format, auth, permissions, schema parsing.
- `5xx` -> inspect server logs and exception traces.

2. API returns unexpected payload?
- Validate controller/service mapping.
- Check schema transform/serialization.
- Compare contract vs implementation.

3. Auth failures?
- Validate token format, expiry, issuer/audience.
- Check cookie settings (`HttpOnly`, `Secure`, domain/path).
- Verify session store connectivity and key rotation.

4. Environment mismatch?
- Confirm env vars present and correct in current environment.
- Validate feature flags and service endpoints.

### 3.4 Database Tree

1. Query failing?
- Check migration state and schema version.
- Validate constraints, nullability, and FK references.

2. Data not persisted?
- Verify transaction commit path and rollback conditions.
- Check errors swallowed in service layer.

3. Performance regression?
- Run `EXPLAIN ANALYZE`.
- Check index usage, cardinality, join order.
- Detect N+1 access patterns and missing pagination.

### 3.5 Network/Infrastructure Tree

1. CORS error?
- Verify allowed origins, methods, headers, and credentials settings.

2. Timeout/connection refused?
- Check service health, ports, DNS, TLS certs, and ingress/proxy rules.

3. Deployment-specific failure?
- Confirm container image/config version.
- Validate secrets/env injection.
- Check health checks/readiness probes.

## 4. Common Issues and Solutions

### 4.1 CORS Errors

Symptoms:
- Browser blocks request with CORS message.

Checks:
- Origin allowlist includes caller.
- `Access-Control-Allow-Credentials` aligns with cookie usage.
- Preflight (`OPTIONS`) handled for custom headers/methods.

### 4.2 Authentication Failures

Checks:
- Token expired or malformed.
- Wrong storage mechanism (cookie vs local storage assumptions).
- Missing `Authorization` header prefix.
- Clock skew and key rotation issues.

### 4.3 Database Errors

Checks:
- Migrations applied in current environment.
- Unique/FK constraint violations.
- ORM schema drift.

### 4.4 Build Failures

Checks:
- Lockfile drift, invalid cache, mismatched Node version.
- If needed: clear build cache, reinstall dependencies.
- Verify environment-specific build flags.

### 4.5 Runtime Errors

Checks:
- Null/undefined access.
- Type mismatches and unsafe casts.
- Unhandled promise rejections.

### 4.6 Performance Issues

Checks:
- Main thread blocking in Performance tab.
- Large bundles or un-split chunks.
- N+1 queries and slow endpoints.

### 4.7 State Management Bugs

Checks:
- Race conditions in async updates.
- Mutating state directly.
- Selector memoization and stale snapshots.

### 4.8 API Errors

Checks:
- Request body/query/path format.
- Content type headers.
- Backend validation response and logs.

## 5. Browser Debugging Playbook (Antigravity)

- Use built-in browser capabilities in Antigravity for reproduction.
- Inspect DOM and computed styles.
- Monitor request/response timing and payloads.
- Check local storage, session storage, and cookies.
- Verify JavaScript execution order and event handling.

## 6. Production Debugging Playbook

- Check Sentry for grouped errors, release tags, affected users.
- Review application and infrastructure logs with correlation IDs.
- Inspect monitoring dashboards for latency/error spikes.
- Verify production-specific config and secrets.
- Reproduce in production-like environment before patching.

## 7. Escalation Rules (Ask Human Help)

Escalate immediately when:
- Security vulnerabilities are found.
- Data loss risk is detected.
- Access to production systems is required.
- Architectural decisions are required beyond scope.
- Debugging exceeds 30 minutes without measurable progress.

## 8. Required Debugging Output

For each incident/bug, provide:
1. Reproduction steps
2. Scope classification (frontend/backend/db/network/infra)
3. Root-cause hypothesis and evidence
4. Fix implemented
5. Verification results
6. Regression test added
7. Remaining risks or follow-up tasks
