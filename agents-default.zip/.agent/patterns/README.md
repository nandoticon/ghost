# Code Patterns
This directory stores reusable code patterns. Use the prescribed template in `knowledge-management-system.md` for new entries.
